package com.sony.travelRequest.model;

public class EmailConstants {
	public static final String FINANCE_DESK_EMAIL = "priyanka.murthy@ap.sony.com";
	//"martin.eapen@ap.sony.com"
}
