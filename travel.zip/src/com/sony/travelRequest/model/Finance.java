package com.sony.travelRequest.model;

public class Finance extends Employee {

}
