package com.sony.travelRequest.model;

public class Manager extends Employee {

}
