package com.sony.travelRequest.model;

public class TravelDesk extends Employee {

}
