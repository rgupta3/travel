package com.sony.travelRequest.model;

public class TravelParamBean {

	private Integer reqId;
	
	private String role;

	public Integer getReqId() {
		return reqId;
	}

	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
}
